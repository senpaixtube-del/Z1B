import * as THREE from "three";
import { defaultMaterial, uid, type BakedGeom, type StudioObject, type Triple } from "./types";
import { useStudio } from "./store";
import { SAMPLE_CHARACTERS } from "./characters";
import {
  formatLoadError,
  folderFromAssetUrl,
  lookupFolder,
  resolveAssetUrl,
  storeBundleAsIdb,
  storeFileAsIdb,
  companionKeysFor,
} from "./asset-db";
import { extractFbxExternalTextures } from "./fbx-media";

export const IMPORT_ACCEPT = [
  ".glb",
  ".gltf",
  ".fbx",
  ".obj",
  ".mtl",
  ".stl",
  ".ply",
  ".dae",
  ".3ds",
  ".3mf",
  ".vtk",
  ".vtp",
  ".xyz",
  ".pcd",
  ".wrl",
  ".usdz",
  ".hdr",
  ".exr",
  ".svg",
  ".png",
  ".jpg",
  ".jpeg",
  ".webp",
  ".tga",
  ".bmp",
  ".tif",
  ".tiff",
  ".json",
  ".bin",
].join(",");

export interface LoadedAsset {
  root: THREE.Object3D;
  clips: THREE.AnimationClip[];
  format: string;
}

export interface ImportResult {
  imported: string[];
  messages: string[];
}

const cache = new Map<string, Promise<LoadedAsset>>();

const TEXTURE_EXT = new Set(["png", "jpg", "jpeg", "webp", "gif", "tga", "bmp", "tif", "tiff"]);
const MODEL_EXT = new Set(["glb", "gltf", "fbx", "obj", "stl", "ply", "dae", "3ds", "3mf", "vtk", "vtp", "xyz", "pcd", "wrl", "usdz", "svg"]);
const SIDECAR_EXT = new Set(["bin", "mtl", ...TEXTURE_EXT]);

function extOf(name: string) {
  return name.split(".").pop()?.toLowerCase() ?? "";
}

function baseOf(name: string) {
  const n = name.replace(/\\/g, "/").split("/").pop() ?? name;
  return n.replace(/\.[^.]+$/, "").toLowerCase();
}

function dirOf(url: string) {
  if (url.startsWith("blob:") || url.startsWith("idb:")) return "";
  const i = url.lastIndexOf("/");
  return i >= 0 ? url.slice(0, i + 1) : "";
}

function sampleFallback(url: string): string | undefined {
  const hit = SAMPLE_CHARACTERS.find((s) => s.url === url || s.cdnUrl === url);
  if (hit?.cdnUrl && hit.cdnUrl !== url) return hit.cdnUrl;
  return undefined;
}

type Sidecar = { file: File; ext: string; base: string; at: number };
const sidecars: Sidecar[] = [];
const SIDECAR_TTL = 15 * 60 * 1000;

function pruneSidecars() {
  const now = Date.now();
  for (let i = sidecars.length - 1; i >= 0; i--) {
    if (now - sidecars[i].at > SIDECAR_TTL) sidecars.splice(i, 1);
  }
}

function rememberSidecar(file: File) {
  pruneSidecars();
  const ext = extOf(file.name);
  const base = baseOf(file.name);
  const idx = sidecars.findIndex((s) => s.base === base && s.ext === ext && s.file.name === file.name);
  const rec: Sidecar = { file, ext, base, at: Date.now() };
  if (idx >= 0) sidecars[idx] = rec;
  else sidecars.push(rec);
}

function takeSidecars(pred: (s: Sidecar) => boolean): File[] {
  pruneSidecars();
  const out: File[] = [];
  for (let i = sidecars.length - 1; i >= 0; i--) {
    if (pred(sidecars[i])) {
      out.push(sidecars[i].file);
      sidecars.splice(i, 1);
    }
  }
  return out;
}

const EMPTY_PNG =
  "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==";

function makeManager(folder: Map<string, string>, localMedia = false) {
  const manager = new THREE.LoadingManager();
  manager.setURLModifier((url) => {
    const hit = lookupFolder(folder, url);
    if (hit) return hit;
    // Local idb/blob imports: never let relative/blob texture paths hit the network
    if (localMedia && (url.startsWith("blob:") || !/^https?:/i.test(url))) return EMPTY_PNG;
    return url;
  });
  return manager;
}

/** FBXLoader.parse returns before async textures finish; wait for LoadingManager. */
function waitForManager(manager: THREE.LoadingManager, timeoutMs = 20000): Promise<void> {
  return new Promise((resolve) => {
    let settled = false;
    const done = () => {
      if (settled) return;
      settled = true;
      resolve();
    };
    const prevLoad = manager.onLoad;
    const prevError = manager.onError;
    manager.onLoad = () => {
      try {
        prevLoad?.();
      } finally {
        done();
      }
    };
    manager.onError = (url) => {
      try {
        prevError?.(url);
      } finally {
        // still resolve — missing maps already fall back to EMPTY_PNG
        const m = manager as THREE.LoadingManager & { itemsLoaded?: number; itemsTotal?: number };
        if (!m.itemsTotal || (m.itemsLoaded ?? 0) >= (m.itemsTotal ?? 0)) done();
      }
    };
    // If nothing was queued (embedded maps / no textures), settle soon
    queueMicrotask(() => {
      const m = manager as THREE.LoadingManager & { itemsLoaded?: number; itemsTotal?: number };
      if (!m.itemsTotal || (m.itemsLoaded ?? 0) >= (m.itemsTotal ?? 0)) done();
    });
    setTimeout(done, timeoutMs);
  });
}

let gltfExtras: Promise<{
  draco: import("three/addons/loaders/DRACOLoader.js").DRACOLoader;
  ktx2: import("three/addons/loaders/KTX2Loader.js").KTX2Loader;
  meshopt: unknown;
}> | null = null;

async function getGltfExtras() {
  if (!gltfExtras) {
    gltfExtras = (async () => {
      const { DRACOLoader } = await import("three/addons/loaders/DRACOLoader.js");
      const { KTX2Loader } = await import("three/addons/loaders/KTX2Loader.js");
      const { MeshoptDecoder } = await import("three/addons/libs/meshopt_decoder.module.js");
      const draco = new DRACOLoader();
      draco.setDecoderPath("/decoders/draco/gltf/");
      const ktx2 = new KTX2Loader();
      ktx2.setTranscoderPath("/decoders/basis/");
      try {
        const canvas = document.createElement("canvas");
        const gl = canvas.getContext("webgl2") || canvas.getContext("webgl");
        if (gl) {
          const renderer = new THREE.WebGLRenderer({ canvas, context: gl as WebGLRenderingContext });
          ktx2.detectSupport(renderer);
          renderer.dispose();
        }
      } catch {
        /* optional */
      }
      const decoder = MeshoptDecoder as { supported?: boolean; ready?: Promise<unknown> };
      if (decoder.supported !== false && decoder.ready) await decoder.ready;
      return { draco, ktx2, meshopt: MeshoptDecoder };
    })();
  }
  return gltfExtras;
}

async function makeGltfLoader(manager?: THREE.LoadingManager) {
  const { GLTFLoader } = await import("three/addons/loaders/GLTFLoader.js");
  const extras = await getGltfExtras();
  const loader = new GLTFLoader(manager);
  loader.setDRACOLoader(extras.draco);
  loader.setKTX2Loader(extras.ktx2);
  const decoder = extras.meshopt as { supported?: boolean };
  if (decoder.supported !== false) loader.setMeshoptDecoder(extras.meshopt as never);
  return loader;
}

function rewriteGltfUris(json: { buffers?: { uri?: string }[]; images?: { uri?: string }[] }, folder: Map<string, string>) {
  const rewrite = (uri?: string) => {
    if (!uri || uri.startsWith("data:") || uri.startsWith("blob:") || /^https?:/i.test(uri)) return uri;
    return lookupFolder(folder, uri) || uri;
  };
  for (const b of json.buffers ?? []) if (b.uri) b.uri = rewrite(b.uri);
  for (const im of json.images ?? []) if (im.uri) im.uri = rewrite(im.uri);
}

function missingGltfUris(
  json: { buffers?: { uri?: string }[]; images?: { uri?: string }[] },
  folder: Map<string, string>,
): string[] {
  const missing: string[] = [];
  const check = (uri?: string) => {
    if (!uri || uri.startsWith("data:") || uri.startsWith("blob:") || /^https?:/i.test(uri)) return;
    if (!lookupFolder(folder, uri)) missing.push(uri);
  };
  for (const b of json.buffers ?? []) check(b.uri);
  for (const im of json.images ?? []) check(im.uri);
  return missing;
}

function folderFromFiles(files: File[], blobUrls: Map<File, string>) {
  const folder = new Map<string, string>();
  for (const f of files) {
    const url = blobUrls.get(f);
    if (!url) continue;
    for (const key of companionKeysFor(f)) folder.set(key, url);
  }
  return folder;
}

export async function loadRuntime(url: string, format: string): Promise<LoadedAsset> {
  let resolved: string;
  try {
    resolved = await resolveAssetUrl(url);
  } catch (err) {
    const fb = sampleFallback(url);
    if (fb) return loadRuntime(fb, format);
    throw err;
  }
  const key = `${format}|${url}|${resolved}`;
  const hit = cache.get(key);
  if (hit) return hit;
  const p = loadRuntimeUncached(resolved, format, url);
  cache.set(key, p);
  try {
    return await p;
  } catch (err) {
    cache.delete(key);
    const fb = sampleFallback(url);
    if (fb && fb !== url && fb !== resolved) return loadRuntime(fb, format);
    throw err;
  }
}

async function loadRuntimeUncached(url: string, format: string, originalUrl: string): Promise<LoadedAsset> {
  const fmt = format.replace(/^\./, "").toLowerCase();
  const storedFolder = await folderFromAssetUrl(originalUrl);
  if (fmt === "glb" || fmt === "gltf") {
    const loader = await makeGltfLoader(storedFolder.size ? makeManager(storedFolder) : undefined);
    if (fmt === "gltf" && storedFolder.size) {
      const res = await fetch(url);
      const json = (await res.json()) as { buffers?: { uri?: string }[]; images?: { uri?: string }[] };
      const missing = missingGltfUris(json, storedFolder);
      if (missing.length) throw new Error(`NEEDS_COMPANIONS:${missing.join(", ")}`);
      rewriteGltfUris(json, storedFolder);
      const blob = new Blob([JSON.stringify(json)], { type: "model/gltf+json" });
      const rewritten = URL.createObjectURL(blob);
      try {
        const gltf = await loader.loadAsync(rewritten);
        return { root: gltf.scene, clips: gltf.animations ?? [], format: fmt };
      } finally {
        URL.revokeObjectURL(rewritten);
      }
    }
    const gltf = await loader.loadAsync(url);
    return { root: gltf.scene, clips: gltf.animations ?? [], format: fmt };
  }
  if (fmt === "fbx") {
    const { FBXLoader } = await import("three/addons/loaders/FBXLoader.js");
    // Local idb/blob: parse(buffer,"") + URLModifier so external textures resolve via companions
    if (storedFolder.size || originalUrl.startsWith("idb:") || url.startsWith("blob:")) {
      const manager = makeManager(storedFolder, true);
      try {
        const { TGALoader } = await import("three/addons/loaders/TGALoader.js");
        manager.addHandler(/\.tga$/i, new TGALoader(manager));
      } catch {
        /* optional */
      }
      const loader = new FBXLoader(manager);
      const res = await fetch(url);
      const buffer = await res.arrayBuffer();
      const group = loader.parse(buffer, "");
      await waitForManager(manager);
      return { root: group, clips: group.animations ?? [], format: "fbx" };
    }
    const manager = storedFolder.size ? makeManager(storedFolder, false) : new THREE.LoadingManager();
    try {
      const { TGALoader } = await import("three/addons/loaders/TGALoader.js");
      manager.addHandler(/\.tga$/i, new TGALoader(manager));
    } catch {
      /* optional */
    }
    const loader = new FBXLoader(manager);
    const resource = dirOf(url);
    if (resource) loader.setResourcePath(resource);
    const group = await loader.loadAsync(url);
    return { root: group, clips: group.animations ?? [], format: "fbx" };
  }
  if (fmt === "obj") {
    const { OBJLoader } = await import("three/addons/loaders/OBJLoader.js");
    const manager = storedFolder.size ? makeManager(storedFolder) : undefined;
    const loader = new OBJLoader(manager);
    const mtlUrl =
      [...storedFolder.entries()].find(([k]) => k.endsWith(".mtl") && k.includes(baseOf(originalUrl)))?.[1] ||
      [...storedFolder.entries()].find(([k]) => k.endsWith(".mtl"))?.[1];
    if (mtlUrl) {
      const { MTLLoader } = await import("three/addons/loaders/MTLLoader.js");
      const mtlLoader = new MTLLoader(manager);
      const creator = await mtlLoader.loadAsync(mtlUrl);
      creator.preload();
      loader.setMaterials(creator);
    }
    const group = await loader.loadAsync(url);
    return { root: group, clips: [], format: "obj" };
  }
  if (fmt === "stl") {
    const { STLLoader } = await import("three/addons/loaders/STLLoader.js");
    const geo = await new STLLoader().loadAsync(url);
    geo.computeVertexNormals();
    const mesh = new THREE.Mesh(
      geo,
      new THREE.MeshStandardMaterial({ color: 0xc5c6ca, metalness: 0.1, roughness: 0.5 }),
    );
    return { root: mesh, clips: [], format: "stl" };
  }
  if (fmt === "ply") {
    const { PLYLoader } = await import("three/addons/loaders/PLYLoader.js");
    const geo = await new PLYLoader().loadAsync(url);
    geo.computeVertexNormals();
    const mesh = new THREE.Mesh(
      geo,
      new THREE.MeshStandardMaterial({ vertexColors: Boolean(geo.getAttribute("color")) }),
    );
    return { root: mesh, clips: [], format: "ply" };
  }
  if (fmt === "dae") {
    const { ColladaLoader } = await import("three/addons/loaders/ColladaLoader.js");
    const collada = await new ColladaLoader().loadAsync(url);
    if (!collada?.scene) throw new Error("Empty Collada");
    return { root: collada.scene, clips: [], format: "dae" };
  }
  if (fmt === "3ds") {
    const { TDSLoader } = await import("three/addons/loaders/TDSLoader.js");
    const obj = await new TDSLoader().loadAsync(url);
    return { root: obj, clips: [], format: "3ds" };
  }
  if (fmt === "3mf") {
    const { ThreeMFLoader } = await import("three/addons/loaders/3MFLoader.js");
    const obj = await new ThreeMFLoader().loadAsync(url);
    return { root: obj, clips: [], format: "3mf" };
  }
  if (fmt === "vtk" || fmt === "vtp") {
    const { VTKLoader } = await import("three/addons/loaders/VTKLoader.js");
    const geo = await new VTKLoader().loadAsync(url);
    geo.computeVertexNormals();
    return { root: new THREE.Mesh(geo, new THREE.MeshStandardMaterial()), clips: [], format: "vtk" };
  }
  if (fmt === "xyz") {
    const { XYZLoader } = await import("three/addons/loaders/XYZLoader.js");
    const geo = await new XYZLoader().loadAsync(url);
    const pts = new THREE.Points(geo, new THREE.PointsMaterial({ size: 0.04, color: 0xe07820 }));
    return { root: pts, clips: [], format: "xyz" };
  }
  if (fmt === "pcd") {
    const { PCDLoader } = await import("three/addons/loaders/PCDLoader.js");
    const pts = await new PCDLoader().loadAsync(url);
    return { root: pts, clips: [], format: "pcd" };
  }
  if (fmt === "wrl") {
    const { VRMLLoader } = await import("three/addons/loaders/VRMLLoader.js");
    const obj = await new VRMLLoader().loadAsync(url);
    return { root: obj, clips: [], format: "wrl" };
  }
  if (fmt === "usdz") {
    const { USDZLoader } = await import("three/addons/loaders/USDZLoader.js");
    const obj = await new USDZLoader().loadAsync(url);
    return { root: obj, clips: [], format: "usdz" };
  }
  if (fmt === "svg") {
    const { SVGLoader } = await import("three/addons/loaders/SVGLoader.js");
    const data = await new SVGLoader().loadAsync(url);
    const g = new THREE.Group();
    for (const p of data.paths) {
      const shapes = SVGLoader.createShapes(p);
      for (const shape of shapes) {
        const mesh = new THREE.Mesh(
          new THREE.ExtrudeGeometry(shape, { depth: 8, bevelEnabled: false }),
          new THREE.MeshStandardMaterial({ color: p.color }),
        );
        g.add(mesh);
      }
    }
    g.scale.set(0.01, -0.01, 0.01);
    return { root: g, clips: [], format: "svg" };
  }
  throw new Error(`Unsupported format: ${fmt}`);
}

function meshToBaked(mesh: THREE.Mesh, name: string): StudioObject | null {
  const geo = (mesh.geometry as THREE.BufferGeometry).clone();
  geo.applyMatrix4(mesh.matrixWorld);
  const pos = geo.getAttribute("position");
  if (!pos) return null;
  const nrm = geo.getAttribute("normal");
  const uv = geo.getAttribute("uv");
  const baked: BakedGeom = {
    position: Array.from(pos.array as Float32Array),
    normal: nrm ? Array.from(nrm.array as Float32Array) : undefined,
    index: geo.index ? (Array.from(geo.index.array as ArrayLike<number>) as number[]) : undefined,
    uv: uv ? Array.from(uv.array as Float32Array) : undefined,
  };
  const world = new THREE.Vector3();
  mesh.getWorldPosition(world);
  const color =
    mesh.material && !Array.isArray(mesh.material) && "color" in mesh.material
      ? "#" + (mesh.material as THREE.MeshStandardMaterial).color.getHexString()
      : "#c5c6ca";
  return {
    id: uid("im"),
    name: mesh.name || name,
    kind: "mesh",
    visible: true,
    position: [world.x, world.y, world.z],
    rotation: [0, 0, 0],
    scale: [1, 1, 1],
    primitive: "baked",
    params: {},
    material: { ...defaultMaterial(mesh.name || "Imported", color) },
    cameraFov: 45,
    modifiers: [],
    keyframes: [],
    baked,
  };
}

function fitAssetScale(root: THREE.Object3D, format: string): Triple {
  const box = new THREE.Box3().setFromObject(root);
  const size = box.getSize(new THREE.Vector3());
  const maxDim = Math.max(size.x, size.y, size.z);
  if (!Number.isFinite(maxDim) || maxDim <= 0) {
    return format === "fbx" ? [0.012, 0.012, 0.012] : [1, 1, 1];
  }
  if (maxDim > 8 || maxDim < 0.35) {
    const s = 1.75 / maxDim;
    return [s, s, s];
  }
  return [1, 1, 1];
}

function makeAssetObject(name: string, url: string, format: string, clips: string[], scale?: Triple): StudioObject {
  return {
    id: uid("as"),
    name,
    kind: "asset",
    visible: true,
    position: [0, 0, 0],
    rotation: [0, 0, 0],
    scale: scale ?? (format === "fbx" ? [0.012, 0.012, 0.012] : [1, 1, 1]),
    primitive: "asset",
    params: {},
    material: defaultMaterial(name),
    cameraFov: 45,
    modifiers: [],
    keyframes: [],
    assetUrl: url,
    assetFormat: format,
    clips,
    clipName: clips[0],
    clipSpeed: 1,
    assetMissing: false,
  };
}

function pickCompanions(main: File, pool: File[], exclusive: boolean): File[] {
  const ext = extOf(main.name);
  const base = baseOf(main.name);
  const sameBase = (f: File) => baseOf(f.name) === base && f !== main;
  if (ext === "glb") return [];
  if (ext === "gltf") {
    const bins = pool.filter((f) => extOf(f.name) === "bin" && (sameBase(f) || exclusive));
    const maps = pool.filter((f) => TEXTURE_EXT.has(extOf(f.name)));
    return [...bins, ...maps];
  }
  if (ext === "fbx") {
    // When exclusive (single model selected / folder import), take all textures in the batch
    return pool.filter((f) => TEXTURE_EXT.has(extOf(f.name)) && (exclusive || sameBase(f)));
  }
  if (ext === "obj") {
    const mtls = pool.filter((f) => extOf(f.name) === "mtl" && (sameBase(f) || exclusive));
    const maps = pool.filter((f) => TEXTURE_EXT.has(extOf(f.name)));
    return [...mtls, ...maps];
  }
  return [];
}

async function importHdri(file: File) {
  const st = useStudio.getState();
  const url = await storeFileAsIdb(file, file.name, file.type);
  st.setCustomHdri(url);
  st.log({ kind: "info", text: `HDRI: ${file.name}` });
}

async function importProject(file: File) {
  const text = await file.text();
  const data = JSON.parse(text) as {
    objects?: StudioObject[];
    lang?: "fa" | "en";
    envPreset?: string;
    pythonCode?: string;
    shading?: string;
    customHdriUrl?: string | null;
  };
  if (!Array.isArray(data.objects)) throw new Error("Invalid project");
  useStudio.getState().hydrate({
    objects: data.objects,
    lang: data.lang,
    pythonCode: data.pythonCode,
    envPreset: data.envPreset as never,
    shading: data.shading as never,
    customHdriUrl: data.customHdriUrl ?? null,
  });
  useStudio.getState().setShowWelcome(false);
}

async function commitModel(file: File, companions: File[]) {
  const fmt = extOf(file.name);
  const st = useStudio.getState();
  const lang = st.lang;
  const fail = (err: unknown) => {
    const msg = formatLoadError(err, file.name, lang);
    st.log({ kind: "err", text: msg });
    throw new Error(msg);
  };

  if (fmt === "gltf") {
    const text = await file.text();
    let json: { buffers?: { uri?: string }[]; images?: { uri?: string }[] };
    try {
      json = JSON.parse(text) as typeof json;
    } catch {
      throw new Error(lang === "fa" ? "فایل GLTF نامعتبر است" : "Invalid GLTF JSON");
    }
    const blobUrls = new Map<File, string>();
    blobUrls.set(file, URL.createObjectURL(file));
    for (const c of companions) blobUrls.set(c, URL.createObjectURL(c));
    const folder = folderFromFiles([file, ...companions], blobUrls);
    const missing = missingGltfUris(json, folder);
    for (const u of blobUrls.values()) URL.revokeObjectURL(u);
    if (missing.length) {
      rememberSidecar(file);
      for (const c of companions) rememberSidecar(c);
      throw new Error(`NEEDS_COMPANIONS:${missing.join(", ")}`);
    }
  }

  if (fmt === "fbx") {
    const buffer = await file.arrayBuffer();
    const needed = extractFbxExternalTextures(buffer);
    if (needed.length) {
      const blobUrls = new Map<File, string>();
      blobUrls.set(file, URL.createObjectURL(file));
      for (const c of companions) blobUrls.set(c, URL.createObjectURL(c));
      const folder = folderFromFiles([file, ...companions], blobUrls);
      const missing = needed.filter((n) => !lookupFolder(folder, n));
      for (const u of blobUrls.values()) URL.revokeObjectURL(u);
      if (missing.length && !companions.length) {
        rememberSidecar(file);
        const names = missing.slice(0, 6).map((m) => m.split(/[/\\]/).pop() ?? m);
        throw new Error(`NEEDS_COMPANIONS:${names.join(", ")}`);
      }
      // If some textures still missing but companions were provided, proceed —
      // makeManager falls back to EMPTY_PNG so load does not hang.
    }
  }

  const stored = companions.length ? await storeBundleAsIdb(file, companions) : await storeFileAsIdb(file, file.name, file.type);
  const keepRig = ["glb", "gltf", "fbx", "dae", "usdz"].includes(fmt);

  try {
    const loaded = await loadRuntime(stored, fmt);
    if (keepRig) {
      const clips = loaded.clips.map((c) => c.name || "clip");
      const obj = makeAssetObject(
        file.name.replace(/\.[^.]+$/, ""),
        stored,
        fmt,
        clips,
        fitAssetScale(loaded.root, fmt),
      );
      st.appendObjects([obj], obj.id);
      if (clips.length) {
        const dur = loaded.clips[0]?.duration ?? 0;
        if (dur > 0) st.setFrameRange(1, Math.max(st.frameEnd, Math.ceil(dur * st.fps) + 1));
        st.setPlaying(true);
        st.setLayout("anim");
      }
      return;
    }

    loaded.root.updateMatrixWorld(true);
    const added: StudioObject[] = [];
    loaded.root.traverse((node) => {
      const mesh = node as THREE.Mesh;
      if (mesh.isMesh) {
        const baked = meshToBaked(mesh, file.name.replace(/\.[^.]+$/, ""));
        if (baked) added.push(baked);
      }
    });
    if (!added.length) {
      const obj = makeAssetObject(
        file.name.replace(/\.[^.]+$/, ""),
        stored,
        fmt,
        [],
        fitAssetScale(loaded.root, fmt),
      );
      st.appendObjects([obj], obj.id);
      return;
    }
    st.appendObjects(added, added[0]?.id ?? null);
  } catch (err) {
    fail(err);
  }
}

export async function importFiles(fileList: File[] | FileList): Promise<ImportResult> {
  const files = Array.from(fileList);
  const imported: string[] = [];
  const messages: string[] = [];
  const st = useStudio.getState();
  const lang = st.lang;
  const fa = lang === "fa";

  if (!files.length) return { imported, messages };

  const jsons = files.filter((f) => extOf(f.name) === "json");
  const hdris = files.filter((f) => extOf(f.name) === "hdr" || extOf(f.name) === "exr");
  const models = files.filter((f) => MODEL_EXT.has(extOf(f.name)));
  const extras = files.filter((f) => SIDECAR_EXT.has(extOf(f.name)));

  for (const f of jsons) {
    await importProject(f);
    imported.push(f.name);
    messages.push(fa ? `پروژه وارد شد: ${f.name}` : `Project loaded: ${f.name}`);
  }

  for (const f of hdris) {
    await importHdri(f);
    imported.push(f.name);
    messages.push(fa ? `HDRI به صحنه اعمال شد: ${f.name}` : `HDRI applied to scene: ${f.name}`);
  }

  if (!models.length) {
    const images = extras.filter((f) => TEXTURE_EXT.has(extOf(f.name)));
    const other = extras.filter((f) => !TEXTURE_EXT.has(extOf(f.name)));
    if (images.length && st.activeId && images.length === extras.length && !other.length) {
      const url = await storeFileAsIdb(images[0], images[0].name, images[0].type);
      st.patchMaterial(st.activeId, { mapUrl: url });
      imported.push(images[0].name);
      messages.push(fa ? `بافت اعمال شد: ${images[0].name}` : `Texture applied: ${images[0].name}`);
      for (const img of images.slice(1)) rememberSidecar(img);
      return { imported, messages };
    }
    for (const f of extras) {
      rememberSidecar(f);
      imported.push(f.name);
    }
    if (extras.length) {
      const names = extras.map((f) => f.name).join(", ");
      messages.push(
        fa
          ? `فایل‌های همراه ذخیره شد (${names}) — مدل (.gltf / .obj / .fbx) را هم انتخاب کنید`
          : `Companions stored (${names}) — import the .gltf / .obj / .fbx next`,
      );
      st.log({ kind: "info", text: messages[messages.length - 1] });
    }
    return { imported, messages };
  }

  const remembered = takeSidecars(() => true);
  const pool = [...extras, ...remembered];
  const exclusive = models.length === 1;
  const used = new Set<File>();

  for (const main of models) {
    let pack = pickCompanions(main, pool.filter((f) => !used.has(f)), exclusive);
    if (extOf(main.name) === "obj") {
      const mtl =
        pack.find((f) => extOf(f.name) === "mtl" && baseOf(f.name) === baseOf(main.name)) ??
        pack.find((f) => extOf(f.name) === "mtl") ??
        remembered.find((f) => extOf(f.name) === "mtl" && baseOf(f.name) === baseOf(main.name));
      if (mtl && !pack.includes(mtl)) pack = [...pack, mtl];
    }
    for (const p of pack) used.add(p);
    await commitModel(main, pack);
    imported.push(main.name);
    const extraNote = pack.length
      ? fa
        ? ` با ${pack.length} فایل همراه`
        : ` + ${pack.length} companion(s)`
      : "";
    messages.push((fa ? `وارد شد: ${main.name}` : `Imported ${main.name}`) + extraNote);
  }

  for (const leftover of pool) {
    if (!used.has(leftover)) rememberSidecar(leftover);
  }

  return { imported, messages };
}

export async function importAnyFile(file: File) {
  const result = await importFiles([file]);
  if (result.messages.length === 1) return;
}

export async function importFromUrl(url: string, format: string, name: string) {
  const loaded = await loadRuntime(url, format);
  const clips = loaded.clips.map((c) => c.name || "clip");
  const obj = makeAssetObject(name, url, format, clips, fitAssetScale(loaded.root, format));
  const st = useStudio.getState();
  st.appendObjects([obj], obj.id);
  if (clips.length) {
    const dur = loaded.clips[0]?.duration ?? 0;
    if (dur > 0) st.setFrameRange(1, Math.max(st.frameEnd, Math.ceil(dur * st.fps) + 1));
    st.setPlaying(true);
  }
  return obj.id;
}
