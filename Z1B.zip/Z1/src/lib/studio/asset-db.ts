import type { StudioObject } from "./types";

const DB_NAME = "zynyx-assets";
const STORE = "files";

export type CompanionBlob = { blob: Blob; name: string; type: string };

export type AssetRecord = {
  blob: Blob;
  name: string;
  type: string;
  companions?: Record<string, CompanionBlob>;
};

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, 1);
    req.onupgradeneeded = () => {
      if (!req.result.objectStoreNames.contains(STORE)) req.result.createObjectStore(STORE);
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error ?? new Error("IDB_OPEN_FAILED"));
  });
}

export async function putAssetFile(
  id: string,
  blob: Blob,
  name: string,
  type: string,
  companions?: Record<string, CompanionBlob>,
) {
  const db = await openDb();
  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction(STORE, "readwrite");
    const rec: AssetRecord = { blob, name, type };
    if (companions && Object.keys(companions).length) rec.companions = companions;
    tx.objectStore(STORE).put(rec, id);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error ?? new Error("IDB_PUT_FAILED"));
  });
}

export async function getAssetRecord(id: string): Promise<AssetRecord | null> {
  try {
    const db = await openDb();
    return await new Promise((resolve, reject) => {
      const tx = db.transaction(STORE, "readonly");
      const req = tx.objectStore(STORE).get(id);
      req.onsuccess = () => resolve((req.result as AssetRecord | undefined) ?? null);
      req.onerror = () => reject(req.error);
    });
  } catch {
    return null;
  }
}

const urlCache = new Map<string, string>();
const companionUrlCache = new Map<string, string>();

export function isIdbUrl(url: string) {
  return url.startsWith("idb:");
}

export function isDeadBlobUrl(url: string) {
  return url.startsWith("blob:");
}

export async function resolveAssetUrl(url: string): Promise<string> {
  if (!url) throw new Error("ASSET_MISSING");
  if (isDeadBlobUrl(url)) throw new Error("ASSET_BLOB_DEAD");
  if (!isIdbUrl(url)) return url;
  const id = url.slice(4);
  const cached = urlCache.get(id);
  if (cached) return cached;
  const rec = await getAssetRecord(id);
  if (!rec) throw new Error("ASSET_MISSING");
  const obj = URL.createObjectURL(rec.blob);
  urlCache.set(id, obj);
  return obj;
}

export async function assetDisplayName(url: string): Promise<string> {
  if (!url) return "";
  if (!isIdbUrl(url)) return url;
  const rec = await getAssetRecord(url.slice(4));
  return rec?.name ?? url;
}

export async function idbExists(url: string): Promise<boolean> {
  if (!url) return false;
  if (!isIdbUrl(url)) return true;
  const rec = await getAssetRecord(url.slice(4));
  return Boolean(rec);
}


function fileRelPath(file: File): string {
  const extra = (file as File & { webkitRelativePath?: string }).webkitRelativePath;
  if (extra) return extra.replace(/\\/g, "/");
  return file.name.replace(/\\/g, "/");
}

export function companionKeysFor(file: File): string[] {
  const rel = fileRelPath(file).toLowerCase().replace(/\\/g, "/");
  const base = rel.split("/").pop() ?? rel;
  const stripped = rel.includes("/") ? rel.slice(rel.indexOf("/") + 1) : rel;
  const parts = rel.split("/").filter(Boolean);
  const keys = new Set<string>([base, rel, stripped, file.name.replace(/\\/g, "/").toLowerCase()]);
  if (parts.length >= 2) keys.add(parts.slice(-2).join("/"));
  const fbm = parts.findIndex((p) => p.endsWith(".fbm"));
  if (fbm >= 0) keys.add(parts.slice(fbm).join("/"));
  return [...keys];
}

function guessMime(name: string, fallback = "application/octet-stream") {
  const ext = name.split(".").pop()?.toLowerCase() ?? "";
  const map: Record<string, string> = {
    gltf: "model/gltf+json",
    glb: "model/gltf-binary",
    bin: "application/octet-stream",
    fbx: "application/octet-stream",
    obj: "text/plain",
    mtl: "text/plain",
    png: "image/png",
    jpg: "image/jpeg",
    jpeg: "image/jpeg",
    webp: "image/webp",
    gif: "image/gif",
    hdr: "application/octet-stream",
    exr: "application/octet-stream",
    tga: "image/x-targa",
    tif: "image/tiff",
    tiff: "image/tiff",
    bmp: "image/bmp",
  };
  return map[ext] ?? fallback;
}

export async function storeFileAsIdb(file: Blob, name: string, type?: string): Promise<string> {
  const id = `f_${Math.random().toString(36).slice(2, 10)}${Date.now().toString(36)}`;
  const mime = type || (file as File).type || guessMime(name);
  try {
    await putAssetFile(id, file, name, mime);
    return `idb:${id}`;
  } catch {
    return URL.createObjectURL(file);
  }
}

export async function storeBundleAsIdb(main: File, companions: File[]): Promise<string> {
  const id = `f_${Math.random().toString(36).slice(2, 10)}${Date.now().toString(36)}`;
  const pack: Record<string, CompanionBlob> = {};
  for (const f of companions) {
    if (f === main) continue;
    const rec: CompanionBlob = { blob: f, name: f.name, type: f.type || guessMime(f.name) };
    for (const key of companionKeysFor(f)) pack[key] = rec;
  }
  try {
    await putAssetFile(id, main, main.name, main.type || guessMime(main.name), pack);
    return `idb:${id}`;
  } catch {
    return URL.createObjectURL(main);
  }
}

function indexBlob(map: Map<string, string>, raw: string, blobUrl: string) {
  const lower = raw.replace(/\\/g, "/").toLowerCase();
  map.set(lower, blobUrl);
  const parts = lower.split("/").filter(Boolean);
  const base = parts[parts.length - 1] ?? lower;
  if (base) map.set(base, blobUrl);
  if (parts.length >= 2) map.set(parts.slice(-2).join("/"), blobUrl);
  const fbm = parts.findIndex((p) => p.endsWith(".fbm"));
  if (fbm >= 0) map.set(parts.slice(fbm).join("/"), blobUrl);
}

export async function folderFromAssetUrl(url: string): Promise<Map<string, string>> {
  const map = new Map<string, string>();
  if (!url || !isIdbUrl(url)) return map;
  const rec = await getAssetRecord(url.slice(4));
  if (!rec) return map;
  const mainUrl = await resolveAssetUrl(url);
  indexBlob(map, rec.name, mainUrl);
  if (!rec.companions) return map;
  for (const [key, c] of Object.entries(rec.companions)) {
    const cacheKey = `${url}|${key}`;
    let blobUrl = companionUrlCache.get(cacheKey);
    if (!blobUrl) {
      blobUrl = URL.createObjectURL(c.blob);
      companionUrlCache.set(cacheKey, blobUrl);
    }
    indexBlob(map, key, blobUrl);
    indexBlob(map, c.name, blobUrl);
  }
  return map;
}

function safeDecode(uri: string) {
  try {
    return decodeURIComponent(uri);
  } catch {
    return uri;
  }
}

export function lookupFolder(folder: Map<string, string>, uri: string): string | undefined {
  if (!uri) return undefined;
  if (uri.startsWith("data:")) return undefined;
  const noHash = uri.split("?")[0].split("#")[0];
  const cleaned = safeDecode(noHash).replace(/\\/g, "/");
  const lower = cleaned.toLowerCase();
  const candidates: string[] = [lower, lower.replace(/^\.\//, "")];

  const blobTail = lower.replace(/^blob:(https?:\/\/[^/]+|null)\//i, "");
  if (blobTail !== lower) {
    candidates.push(blobTail);
    candidates.push(blobTail.replace(/^\.\//, ""));
  }
  candidates.push(lower.replace(/^file:\/\//, ""));

  const parts = lower.split("/").filter((p) => p && p !== "." && p !== "..");
  const base = parts[parts.length - 1] ?? lower.split("/").pop() ?? lower;
  candidates.push(base);
  if (parts.length >= 2) candidates.push(parts.slice(-2).join("/"));
  const fbm = parts.findIndex((p) => p.endsWith(".fbm"));
  if (fbm >= 0) candidates.push(parts.slice(fbm).join("/"));

  for (const c of candidates) {
    const hit = folder.get(c);
    if (hit) return hit;
  }

  const baseNoExt = base.replace(/\.[^.]+$/, "");
  if (baseNoExt && baseNoExt !== base) {
    for (const [key, val] of folder) {
      const keyBase = key.split("/").pop() ?? key;
      if (keyBase === base) return val;
      const keyNoExt = keyBase.replace(/\.[^.]+$/, "");
      if (keyNoExt === baseNoExt) return val;
    }
  } else {
    for (const [key, val] of folder) {
      const keyBase = key.split("/").pop() ?? key;
      if (keyBase === base) return val;
    }
  }
  return undefined;
}

export async function annotateMissingAssets(objects: StudioObject[]): Promise<{
  objects: StudioObject[];
  missing: number;
}> {
  const next: StudioObject[] = [];
  for (const o of objects) {
    let assetUrl = o.assetUrl;
    let assetMissing = o.assetMissing ?? false;
    let mapUrl = o.material?.mapUrl;
    if (assetUrl && isDeadBlobUrl(assetUrl)) {
      assetUrl = undefined;
      assetMissing = true;
    } else if (assetUrl && isIdbUrl(assetUrl)) {
      const rec = await getAssetRecord(assetUrl.slice(4));
      if (!rec) {
        assetUrl = undefined;
        assetMissing = true;
      }
    }
    if (mapUrl && isDeadBlobUrl(mapUrl)) mapUrl = undefined;
    else if (mapUrl && isIdbUrl(mapUrl)) {
      const rec = await getAssetRecord(mapUrl.slice(4));
      if (!rec) mapUrl = undefined;
    }
    next.push({
      ...o,
      assetUrl,
      assetMissing,
      material: { ...o.material, mapUrl },
    });
  }
  return {
    objects: next,
    missing: next.filter((o) => o.assetMissing || (o.kind === "asset" && !o.assetUrl)).length,
  };
}

export function formatLoadError(err: unknown, name: string, lang: "fa" | "en") {
  const raw = err instanceof Error ? err.message : String(err);
  if (raw === "ASSET_MISSING" || raw === "ASSET_BLOB_DEAD") {
    return lang === "fa"
      ? `${name}: فایل ذخیره‌شده پیدا نشد — دوباره ایمپورت کنید`
      : `${name}: saved file missing — re-import the model`;
  }
  if (raw.startsWith("NEEDS_COMPANIONS:")) {
    const need = raw.slice("NEEDS_COMPANIONS:".length);
    return lang === "fa"
      ? `${name}: فایل‌های همراه لازم است (${need}). همه را با هم انتخاب کنید، یا به GLB تبدیل کنید.`
      : `${name}: companion files required (${need}). Select them together, or convert to GLB.`;
  }
  return lang === "fa" ? `لود ناموفق ${name}: ${raw}` : `Load failed ${name}: ${raw}`;
}
