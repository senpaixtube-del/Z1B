/** Extract external (non-embedded) texture paths referenced by an FBX. */

const IMAGE_EXT = /\.(png|jpe?g|webp|gif|tga|bmp|tiff?|psd)$/i;

function uniquePaths(xs: string[]): string[] {
  const seen = new Set<string>();
  const out: string[] = [];
  for (const raw of xs) {
    const n = raw.replace(/\\/g, "/").trim();
    if (!n) continue;
    const k = n.toLowerCase();
    if (seen.has(k)) continue;
    seen.add(k);
    out.push(n);
  }
  return out;
}

export function isFbxBinary(buffer: ArrayBuffer): boolean {
  if (buffer.byteLength < 27) return false;
  const sig = new TextDecoder("latin1").decode(new Uint8Array(buffer, 0, 21));
  return sig.startsWith("Kaydara FBX Binary");
}

export function extractFbxExternalTextures(buffer: ArrayBuffer): string[] {
  try {
    if (isFbxBinary(buffer)) return uniquePaths(walkBinaryVideos(buffer));
    const text = new TextDecoder("latin1").decode(new Uint8Array(buffer));
    return uniquePaths(walkAsciiVideos(text));
  } catch {
    return [];
  }
}

function walkAsciiVideos(text: string): string[] {
  const out: string[] = [];
  const re = /Video\s*:[^{]*\{([\s\S]*?)\}/gi;
  let m: RegExpExecArray | null;
  while ((m = re.exec(text))) {
    const body = m[1];
    const content = /Content\s*:\s*("[\s\S]*?"|[^\n]*)/i.exec(body)?.[1]?.trim() ?? "";
    const embedded =
      content.length > 16 &&
      content !== '""' &&
      !/^0+,?$/.test(content) &&
      !/^,\s*$/.test(content);
    if (embedded) continue;
    const rel =
      /RelativeFileName\s*:\s*"([^"]+)"/i.exec(body)?.[1] ??
      /RelativeFilename\s*:\s*"([^"]+)"/i.exec(body)?.[1];
    const fn =
      /FileName\s*:\s*"([^"]+)"/i.exec(body)?.[1] ??
      /Filename\s*:\s*"([^"]+)"/i.exec(body)?.[1];
    for (const name of [rel, fn]) {
      if (name && IMAGE_EXT.test(name)) out.push(name);
    }
  }
  return out;
}

function walkBinaryVideos(buffer: ArrayBuffer): string[] {
  const view = new DataView(buffer);
  const decoder = new TextDecoder("latin1");
  const version = view.getUint32(23, true);
  const u64 = version >= 7500;
  let offset = 27;
  const out: string[] = [];

  const readU32 = () => {
    const v = view.getUint32(offset, true);
    offset += 4;
    return v;
  };
  const readU64 = () => {
    const lo = view.getUint32(offset, true);
    const hi = view.getUint32(offset + 4, true);
    offset += 8;
    return lo + hi * 4294967296;
  };
  const readSize = () => (u64 ? readU64() : readU32());

  const parseHeader = (): { name: string; endOffset: number; propListLen: number } | null => {
    if (offset + (u64 ? 25 : 13) > buffer.byteLength) return null;
    const endOffset = readSize();
    if (endOffset === 0) return null;
    readSize(); // numProperties
    const propListLen = readSize();
    const nameLen = view.getUint8(offset);
    offset += 1;
    const name = decoder.decode(new Uint8Array(buffer, offset, nameLen));
    offset += nameLen;
    return { name, endOffset, propListLen };
  };

  const firstStringProp = (propStart: number, propListLen: number): string | undefined => {
    if (propListLen < 5) return undefined;
    const type = String.fromCharCode(view.getUint8(propStart));
    if (type !== "S") return undefined;
    const len = view.getUint32(propStart + 1, true);
    if (len <= 0 || propStart + 5 + len > buffer.byteLength) return undefined;
    return decoder.decode(new Uint8Array(buffer, propStart + 5, len));
  };

  const contentEmbedded = (propStart: number, propListLen: number): boolean => {
    if (propListLen < 5) return false;
    const type = String.fromCharCode(view.getUint8(propStart));
    if (type === "R" || type === "S") {
      const len = view.getUint32(propStart + 1, true);
      return len > 16;
    }
    return propListLen > 32;
  };

  const extractVideo = (endOffset: number, propListLen: number) => {
    offset += propListLen;
    let relative: string | undefined;
    let filename: string | undefined;
    let embedded = false;
    while (offset < endOffset) {
      const child = parseHeader();
      if (!child) break;
      const propStart = offset;
      const nm = child.name;
      if (nm === "RelativeFilename" || nm === "RelativeFileName") {
        relative = firstStringProp(propStart, child.propListLen) ?? relative;
      } else if (nm === "FileName" || nm === "Filename") {
        filename = firstStringProp(propStart, child.propListLen) ?? filename;
      } else if (nm === "Content" && contentEmbedded(propStart, child.propListLen)) {
        embedded = true;
      }
      offset = child.endOffset;
    }
    offset = endOffset;
    if (embedded) return;
    for (const name of [relative, filename]) {
      if (name && IMAGE_EXT.test(name)) out.push(name);
    }
  };

  const walk = () => {
    const header = parseHeader();
    if (!header) return;
    if (header.name === "Video") {
      extractVideo(header.endOffset, header.propListLen);
      return;
    }
    if (header.name === "Objects") {
      offset += header.propListLen;
      while (offset < header.endOffset) walk();
      offset = header.endOffset;
      return;
    }
    offset = header.endOffset;
  };

  while (offset < buffer.byteLength - (u64 ? 25 : 13)) {
    const before = offset;
    walk();
    if (offset <= before) break;
  }
  return out;
}
