import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { extractFbxExternalTextures, isFbxBinary } from "./fbx-media.ts";

describe("extractFbxExternalTextures", () => {
  it("extracts RelativeFilename from ASCII Video nodes without Content", () => {
    const ascii = `
; FBX 7.4.0 project file
Objects:  {
  Video: 123, "Video::Diffuse", "Clip" {
    Type: "Clip"
    Filename: "C:\\Maps\\body_d.png"
    RelativeFilename: "textures\\body_d.png"
    Content: ""
  }
  Video: 456, "Video::Normal", "Clip" {
    Type: "Clip"
    RelativeFilename: "textures/body_n.jpg"
    Content: ,
  }
}
`;
    const buf = new TextEncoder().encode(ascii).buffer;
    assert.equal(isFbxBinary(buf), false);
    const paths = extractFbxExternalTextures(buf);
    assert.ok(paths.some((p) => /body_d\.png$/i.test(p)));
    assert.ok(paths.some((p) => /body_n\.jpg$/i.test(p)));
  });

  it("skips embedded Content videos", () => {
    const ascii = `
Objects:  {
  Video: 1, "Video::Embed", "Clip" {
    Type: "Clip"
    RelativeFilename: "embedded.png"
    Content: "lots of base64 data that is longer than sixteen chars"
  }
}
`;
    const paths = extractFbxExternalTextures(new TextEncoder().encode(ascii).buffer);
    assert.equal(paths.length, 0);
  });

  it("returns empty for non-fbx garbage", () => {
    const buf = new TextEncoder().encode("not an fbx at all").buffer;
    assert.deepEqual(extractFbxExternalTextures(buf), []);
  });

  it("dedupes case-insensitive paths", () => {
    const ascii = `
Objects:  {
  Video: 1, "Video::A", "Clip" {
    RelativeFilename: "Foo/Bar.PNG"
    Content: ""
  }
  Video: 2, "Video::B", "Clip" {
    RelativeFilename: "foo/bar.png"
    Content: ""
  }
}
`;
    const paths = extractFbxExternalTextures(new TextEncoder().encode(ascii).buffer);
    assert.equal(paths.length, 1);
  });

  it("detects binary signature", () => {
    const bytes = new Uint8Array(40);
    const sig = new TextEncoder().encode("Kaydara FBX Binary  \x00");
    bytes.set(sig, 0);
    assert.equal(isFbxBinary(bytes.buffer), true);
  });

  it("ignores non-image RelativeFilename", () => {
    const ascii = `
Objects:  {
  Video: 1, "Video::X", "Clip" {
    RelativeFilename: "something.bin"
    Content: ""
  }
}
`;
    const paths = extractFbxExternalTextures(new TextEncoder().encode(ascii).buffer);
    assert.equal(paths.length, 0);
  });
});
