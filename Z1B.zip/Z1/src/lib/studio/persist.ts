import { isDeadBlobUrl, isIdbUrl, idbExists } from "./asset-db";
import { useStudio } from "./store";
import type { StudioObject } from "./types";

const KEY = "zynyx.project.v1";
const LEGACY = "lumina.project.v1";

export interface Persisted {
  objects: StudioObject[];
  lang: "fa" | "en";
  envPreset: string;
  pythonCode: string;
  shading: string;
  customHdriUrl?: string | null;
  missingAssets?: number;
}

function sanitizeObject(o: StudioObject): StudioObject {
  let assetUrl = o.assetUrl;
  let mapUrl = o.material?.mapUrl;
  let assetMissing = o.assetMissing ?? false;
  if (assetUrl && isDeadBlobUrl(assetUrl)) {
    assetUrl = undefined;
    assetMissing = true;
  }
  if (mapUrl && isDeadBlobUrl(mapUrl)) {
    mapUrl = undefined;
  }
  return {
    ...o,
    assetUrl,
    assetMissing,
    material: { ...o.material, mapUrl },
  };
}

export function loadProject(): Persisted | null {
  if (typeof localStorage === "undefined") return null;
  try {
    const raw = localStorage.getItem(KEY) ?? localStorage.getItem(LEGACY);
    if (!raw) return null;
    const data = JSON.parse(raw) as Persisted;
    const objects = (data.objects ?? []).map(sanitizeObject);
    const missingAssets = objects.filter((o) => o.assetMissing || (o.kind === "asset" && !o.assetUrl)).length;
    let customHdriUrl = data.customHdriUrl ?? null;
    if (customHdriUrl && isDeadBlobUrl(customHdriUrl)) customHdriUrl = null;
    return { ...data, objects, missingAssets, customHdriUrl };
  } catch {
    return null;
  }
}

export async function restoreCustomHdri(url: string | null | undefined): Promise<string | null> {
  if (!url) return null;
  if (isDeadBlobUrl(url)) return null;
  if (isIdbUrl(url) && !(await idbExists(url))) return null;
  return url;
}

export function saveProject() {
  if (typeof localStorage === "undefined") return;
  const s = useStudio.getState();
  const data: Persisted = {
    objects: s.objects.map(sanitizeObject),
    lang: s.lang,
    envPreset: s.envPreset,
    pythonCode: s.pythonCode,
    shading: s.shading,
    customHdriUrl: s.customHdriUrl,
  };
  try {
    localStorage.setItem(KEY, JSON.stringify(data));
  } catch {
    /* quota */
  }
}

export function subscribePersist() {
  let t: ReturnType<typeof setTimeout> | undefined;
  return useStudio.subscribe(() => {
    if (t) clearTimeout(t);
    t = setTimeout(saveProject, 450);
  });
}
